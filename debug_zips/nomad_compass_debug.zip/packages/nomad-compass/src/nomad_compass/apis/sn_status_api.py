from fastapi import APIRouter, Request
router = APIRouter(prefix="/status")

@router.get("/ping")
async def ping():
    return {"status": "ok"}

@router.get("/ready")
async def ready(request: Request):
    services = getattr(request.app.state, "services", None)
    if not services:
        return {"ready": False}
    vs = services.get("vector_store")
    try:
        return {"ready": bool(vs and getattr(vs, "is_ready", lambda: False)())}
    except Exception:
        return {"ready": False}

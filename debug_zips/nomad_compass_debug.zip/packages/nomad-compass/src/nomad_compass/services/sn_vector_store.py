# sn_vector_store.py
from __future__ import annotations
from typing import Any, List, Tuple, Sequence

class SimpleVectorStore:
    """
    Minimal async-friendly in-memory vector store with:
      - build_index(docs): builds a trivial index (placeholder)
      - set_index(docs, vecs): set from cache
      - get_index(): returns (docs, vecs)
      - is_ready(): True if index is present and non-empty
    """
    def __init__(self) -> None:
        self._docs: List[dict] = []
        self._vecs: List[Any] | None = None

    def set_index(self, docs: Sequence[dict] | None, vecs: Sequence[Any] | None) -> None:
        self._docs = list(docs or [])
        self._vecs = list(vecs or [])

    def get_index(self) -> Tuple[List[dict], List[Any] | None]:
        return self._docs, self._vecs

    async def build_index(self, docs: Sequence[dict]) -> None:
        """
        Build a trivial 'embedding' so the pipeline works end-to-end.
        Replace this with your real embeddings later.
        """
        # trivial fixed-length vector per doc to mark presence
        vecs = [0] * len(docs)
        self.set_index(docs, vecs)

    def is_ready(self) -> bool:
        return self._vecs is not None and len(self._docs) > 0 and len(self._vecs) == len(self._docs)

    async def aclose(self) -> None:
        # nothing to close in this simple impl
        pass
